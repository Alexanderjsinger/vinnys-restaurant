import "server-only";
import {
  addEvent,
  addHour,
  addInquiry,
  addItem,
  addSection,
  deleteEvent,
  deleteHour,
  deleteInquiry,
  deleteItem,
  deleteSection,
  getDb,
  listHours,
  moveHour,
  moveItem,
  moveSection,
  saveSetting,
  sectionExists,
  updateEvent,
  updateHour,
  updateItem,
  updateSection,
} from "./db";
import {
  asId,
  cleanEventPhoto,
  cleanText,
  detroitToday,
  isEmail,
  isValidDate,
  normalizeDateTime,
  normalizeTime,
  parseProvider,
  safeHttpUrl,
} from "./format";
import { recordTrack } from "./track";
import type { PartyDraft, SettingKey } from "./types";

function checked(form: FormData, name: string): boolean {
  return form.get(name) === "on" || form.get(name) === "1";
}

function direction(form: FormData): "up" | "down" | null {
  const value = String(form.get("dir") ?? "");
  if (value === "up" || value === "down") return value;
  return null;
}

export function applyAdminSave(form: FormData): string {
  const intent = String(form.get("intent") ?? "");
  switch (intent) {
    case "place":
      return savePlace(form);
    case "story":
      return saveStory(form);
    case "promo":
      return savePromo(form);
    case "ordering":
      return saveOrdering(form);
    case "reservations":
      return saveReservations(form);
    case "hour-add":
      return saveHourAdd(form);
    case "hour-delete":
      return saveHourDelete(form);
    case "hour-move":
      return saveHourMove(form);
    case "section-add":
      return saveSectionAdd(form);
    case "section-update":
      return saveSectionUpdate(form);
    case "section-delete":
      return saveSectionDelete(form);
    case "section-move":
      return saveSectionMove(form);
    case "item-add":
      return saveItemAdd(form);
    case "item-update":
      return saveItemUpdate(form);
    case "item-delete":
      return saveItemDelete(form);
    case "item-move":
      return saveItemMove(form);
    case "event-add":
      return saveEventAdd(form);
    case "event-update":
      return saveEventUpdate(form);
    case "event-delete":
      return saveEventDelete(form);
    case "inquiry-delete":
      return saveInquiryDelete(form);
    default:
      return "/admin?error=unknown";
  }
}

function savePlace(form: FormData): string {
  const name = cleanText(form.get("restaurant_name"), 120);
  const address = cleanText(form.get("address"), 200);
  const phone = cleanText(form.get("phone"), 40);
  const email = cleanText(form.get("email"), 200);
  if (!name || !address) return "/admin/place?error=required";
  if (email && !isEmail(email)) return "/admin/place?error=email";

  const ids = form.getAll("hour_id").map((value) => asId(value));
  if (ids.some((id) => id === null)) return "/admin/place?error=time";
  const hourIds = ids as number[];
  const known = new Set(listHours().map((hour) => hour.id));
  const hours = hourIds.map((id) => {
    const label = cleanText(form.get(`hour_label_${id}`), 80);
    const opens = normalizeTime(String(form.get(`hour_opens_${id}`) ?? ""));
    const closes = normalizeTime(String(form.get(`hour_closes_${id}`) ?? ""));
    const confirmed = checked(form, `hour_confirmed_${id}`);
    return { id, label, opens, closes, confirmed };
  });
  if (hours.some((hour) => !known.has(hour.id) || !hour.label || !hour.opens || !hour.closes)) {
    return "/admin/place?error=time";
  }

  const tx = getDb().transaction(() => {
    saveSetting("restaurant_name", name, checked(form, "restaurant_name_confirmed"));
    saveSetting("address", address, checked(form, "address_confirmed"));
    saveSetting("phone", phone, phone.length > 0 && checked(form, "phone_confirmed"));
    saveSetting("email", email, email.length > 0 && checked(form, "email_confirmed"));
    for (const hour of hours) {
      updateHour({
        id: hour.id,
        label: hour.label,
        opens: hour.opens as string,
        closes: hour.closes as string,
        confirmed: hour.confirmed,
      });
    }
  });
  tx();
  return "/admin/place?saved=1";
}

function saveHourAdd(form: FormData): string {
  const label = cleanText(form.get("label"), 80);
  const opens = normalizeTime(String(form.get("opens") ?? ""));
  const closes = normalizeTime(String(form.get("closes") ?? ""));
  if (!label || !opens || !closes) return "/admin/place?error=time";
  addHour(label, opens, closes);
  return "/admin/place?saved=1";
}

function saveHourDelete(form: FormData): string {
  const id = asId(form.get("id"));
  if (!id || !checked(form, "yes")) return "/admin/place?error=confirm";
  deleteHour(id);
  return "/admin/place?saved=1";
}

function saveHourMove(form: FormData): string {
  const id = asId(form.get("id"));
  const dir = direction(form);
  if (!id || !dir) return "/admin/place?error=unknown";
  moveHour(id, dir);
  return "/admin/place?saved=1";
}

function saveStory(form: FormData): string {
  const fields: { key: SettingKey; max: number }[] = [
    { key: "tagline", max: 160 },
    { key: "owner_name", max: 120 },
    { key: "opened_on", max: 20 },
    { key: "former_venue", max: 120 },
    { key: "cuisine_summary", max: 600 },
  ];
  const opened = cleanText(form.get("opened_on"), 20);
  if (opened && !isValidDate(opened)) return "/admin/story?error=date";

  const tx = getDb().transaction(() => {
    for (const field of fields) {
      const value = cleanText(form.get(field.key), field.max);
      const confirmed = value.length > 0 && checked(form, `${field.key}_confirmed`);
      saveSetting(field.key, value, confirmed);
    }
  });
  tx();
  return "/admin/story?saved=1";
}

function savePromo(form: FormData): string {
  const headline = cleanText(form.get("promo_headline"), 160);
  const body = cleanText(form.get("promo_body"), 1200);
  const linkLabel = cleanText(form.get("promo_link_label"), 80);
  const linkRaw = cleanText(form.get("promo_link_url"), 500);
  if ((linkLabel && !linkRaw) || (!linkLabel && linkRaw)) return "/admin/promo?error=link";
  if (linkRaw && !safeHttpUrl(linkRaw)) return "/admin/promo?error=url";
  const tx = getDb().transaction(() => {
    saveSetting("promo_headline", headline, false);
    saveSetting("promo_body", body, false);
    saveSetting("promo_link_label", linkLabel, false);
    saveSetting("promo_link_url", linkRaw ? (safeHttpUrl(linkRaw) as string) : "", false);
  });
  tx();
  return "/admin/promo?saved=1";
}

function saveOrdering(form: FormData): string {
  const raw = cleanText(form.get("toast_ordering_url"), 500);
  if (raw && !safeHttpUrl(raw)) return "/admin/ordering?error=url";
  saveSetting("toast_ordering_url", raw ? (safeHttpUrl(raw) as string) : "", false);
  return "/admin/ordering?saved=1";
}

function saveReservations(form: FormData): string {
  const provider = parseProvider(String(form.get("reservation_provider") ?? "none"));
  const raw = cleanText(form.get("reservation_url"), 500);
  const posted = String(form.get("reservation_provider") ?? "none");
  if (!["none", "toast", "opentable", "resy"].includes(posted)) {
    return "/admin/reservations?error=provider";
  }
  if (raw && !safeHttpUrl(raw)) return "/admin/reservations?error=url";
  const tx = getDb().transaction(() => {
    saveSetting("reservation_provider", provider, false);
    saveSetting("reservation_url", raw ? (safeHttpUrl(raw) as string) : "", false);
  });
  tx();
  return "/admin/reservations?saved=1";
}

function saveSectionAdd(form: FormData): string {
  const name = cleanText(form.get("name"), 80);
  const blurb = cleanText(form.get("blurb"), 240);
  if (!name) return "/admin/menu?error=required";
  addSection(name, blurb);
  return "/admin/menu?saved=1";
}

function saveSectionUpdate(form: FormData): string {
  const id = asId(form.get("id"));
  const name = cleanText(form.get("name"), 80);
  const blurb = cleanText(form.get("blurb"), 240);
  if (!id || !name) return "/admin/menu?error=required";
  updateSection(id, name, blurb);
  return "/admin/menu?saved=1";
}

function saveSectionDelete(form: FormData): string {
  const id = asId(form.get("id"));
  if (!id || !checked(form, "yes")) return "/admin/menu?error=confirm";
  deleteSection(id);
  return "/admin/menu?saved=1";
}

function saveSectionMove(form: FormData): string {
  const id = asId(form.get("id"));
  const dir = direction(form);
  if (!id || !dir) return "/admin/menu?error=unknown";
  moveSection(id, dir);
  return "/admin/menu?saved=1";
}

function itemInput(form: FormData) {
  return {
    name: cleanText(form.get("name"), 120),
    description: cleanText(form.get("description"), 400),
    price: cleanText(form.get("price"), 40),
    isSample: checked(form, "is_sample"),
  };
}

function saveItemAdd(form: FormData): string {
  const sectionId = asId(form.get("section_id"));
  const item = itemInput(form);
  if (!sectionId || !sectionExists(sectionId) || !item.name || !item.price) {
    return "/admin/menu?error=required";
  }
  addItem({ sectionId, ...item });
  return "/admin/menu?saved=1";
}

function saveItemUpdate(form: FormData): string {
  const id = asId(form.get("id"));
  const sectionId = asId(form.get("section_id"));
  const item = itemInput(form);
  if (!id || !sectionId || !sectionExists(sectionId) || !item.name || !item.price) {
    return "/admin/menu?error=required";
  }
  updateItem({ id, sectionId, ...item });
  return "/admin/menu?saved=1";
}

function saveItemDelete(form: FormData): string {
  const id = asId(form.get("id"));
  if (!id || !checked(form, "yes")) return "/admin/menu?error=confirm";
  deleteItem(id);
  return "/admin/menu?saved=1";
}

function saveItemMove(form: FormData): string {
  const id = asId(form.get("id"));
  const dir = direction(form);
  if (!id || !dir) return "/admin/menu?error=unknown";
  moveItem(id, dir);
  return "/admin/menu?saved=1";
}

function eventInput(form: FormData) {
  const photo = cleanEventPhoto(cleanText(form.get("photo"), 300));
  return {
    title: cleanText(form.get("title"), 120),
    startsAt: normalizeDateTime(String(form.get("starts_at") ?? "")),
    blurb: cleanText(form.get("blurb"), 400),
    isSample: checked(form, "is_sample"),
    price: cleanText(form.get("price"), 40),
    photo,
    nextStep: cleanText(form.get("next_step"), 200),
  };
}

function saveEventAdd(form: FormData): string {
  const event = eventInput(form);
  if (!event.title || !event.startsAt || !event.blurb) return "/admin/events?error=required";
  if (event.photo === null) return "/admin/events?error=url";
  addEvent({
    title: event.title,
    startsAt: event.startsAt,
    blurb: event.blurb,
    isSample: event.isSample,
    price: event.price,
    photo: event.photo,
    nextStep: event.nextStep,
  });
  return "/admin/events?saved=1";
}

function saveEventUpdate(form: FormData): string {
  const id = asId(form.get("id"));
  const event = eventInput(form);
  if (!id || !event.title || !event.startsAt || !event.blurb) return "/admin/events?error=required";
  if (event.photo === null) return "/admin/events?error=url";
  updateEvent({
    id,
    title: event.title,
    startsAt: event.startsAt,
    blurb: event.blurb,
    isSample: event.isSample,
    price: event.price,
    photo: event.photo,
    nextStep: event.nextStep,
  });
  return "/admin/events?saved=1";
}

function saveEventDelete(form: FormData): string {
  const id = asId(form.get("id"));
  if (!id || !checked(form, "yes")) return "/admin/events?error=confirm";
  deleteEvent(id);
  return "/admin/events?saved=1";
}

function saveInquiryDelete(form: FormData): string {
  const id = asId(form.get("id"));
  if (!id || !checked(form, "yes")) return "/admin/inquiries?error=confirm";
  deleteInquiry(id);
  return "/admin/inquiries?saved=1";
}

type InquiryResult =
  | { ok: true; stored: boolean }
  | { ok: false; errors: string[]; draft: PartyDraft };

export async function submitInquiry(form: FormData): Promise<InquiryResult> {
  const draft: PartyDraft = {
    name: cleanText(form.get("name"), 120),
    email: cleanText(form.get("email"), 200),
    event_date: cleanText(form.get("event_date"), 20),
    party_size: cleanText(form.get("party_size"), 10),
    message: cleanText(form.get("event_type") ?? form.get("message"), 200),
  };
  if (cleanText(form.get("company_website"), 200)) {
    return { ok: true, stored: false };
  }

  const errors: string[] = [];
  if (!draft.name) errors.push("name");
  if (!isEmail(draft.email)) errors.push("email");
  if (!isValidDate(draft.event_date) || draft.event_date < detroitToday()) errors.push("date");
  const size = Number(draft.party_size);
  if (!/^\d+$/.test(draft.party_size) || !Number.isInteger(size) || size < 1 || size > 500) {
    errors.push("size");
  }
  if (!draft.message) errors.push("event");
  if (errors.length) return { ok: false, errors, draft };

  await addInquiry({
    name: draft.name,
    email: draft.email,
    eventDate: draft.event_date,
    partySize: Number(draft.party_size),
    message: draft.message,
  });
  try {
    await recordTrack("party_inquiry_submit");
  } catch {
    // The inquiry is already stored.
  }
  return { ok: true, stored: true };
}
