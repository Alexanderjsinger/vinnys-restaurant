import "server-only";
import fs from "fs";
import path from "path";
import { createRequire } from "node:module";
import type Database from "better-sqlite3";
import snapshotFile from "./public-snapshot.json";
import { LUNCH_MENU, LUNCH_PROMO_BODY, PREVIOUS_PROMO_BODY } from "./lunch-menu";
import { ORDER_URL, PHONE_DISPLAY } from "./public";
import {
  SETTING_KEYS,
  type EventRow,
  type Hour,
  type Inquiry,
  type MenuItem,
  type MenuSection,
  type SettingKey,
  type SettingsMap,
} from "./types";

type SettingRow = { key: string; value: string; confirmed: number };
type HourRow = {
  id: number;
  label: string;
  opens: string;
  closes: string;
  confirmed: number;
  sort_order: number;
};
type SectionRow = { id: number; name: string; blurb: string; sort_order: number };
type ItemRow = {
  id: number;
  section_id: number;
  name: string;
  description: string;
  price: string;
  sort_order: number;
  is_sample: number;
  gluten_free: number;
  marked: number;
};
type EventDbRow = {
  id: number;
  title: string;
  starts_at: string;
  blurb: string;
  is_sample: number;
  price: string;
  photo: string;
  next_step: string;
};

const globalForDb = globalThis as unknown as { vinnysDb?: Database.Database };
const nodeRequire = createRequire(import.meta.url);

type PublicSnapshot = {
  settings: SettingsMap;
  hours: Hour[];
  menu: MenuSection[];
  events: EventRow[];
};

const publicSnapshot = snapshotFile as PublicSnapshot;

function onPublicDeploy(): boolean {
  return process.env.VINNYS_SNAPSHOT === "1";
}

function migrate(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      confirmed INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS hours (
      id INTEGER PRIMARY KEY,
      label TEXT NOT NULL,
      opens TEXT NOT NULL,
      closes TEXT NOT NULL,
      confirmed INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS menu_sections (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      blurb TEXT NOT NULL DEFAULT '',
      sort_order INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY,
      section_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      price TEXT NOT NULL,
      sort_order INTEGER NOT NULL,
      is_sample INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (section_id) REFERENCES menu_sections(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      starts_at TEXT NOT NULL,
      blurb TEXT NOT NULL,
      is_sample INTEGER NOT NULL DEFAULT 0,
      price TEXT NOT NULL DEFAULT '',
      photo TEXT NOT NULL DEFAULT '',
      next_step TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS inquiries (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      event_date TEXT NOT NULL,
      party_size INTEGER NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS signups (
      id INTEGER PRIMARY KEY,
      email TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  ensureMenuColumns(db);
  ensureEventColumns(db);

  const seeded = db.prepare("SELECT value FROM meta WHERE key = 'seeded'").get() as
    | { value: string }
    | undefined;
  if (seeded?.value === "1") {
    replaceLunchMenu(db);
    confirmKnownFacts(db);
    return;
  }

  const insertSetting = db.prepare(
    "INSERT INTO settings (key, value, confirmed) VALUES (?, ?, 0)",
  );
  const settings: [SettingKey, string][] = [
    ["restaurant_name", "Vinny's Bar & Grill"],
    ["tagline", "Good Food, Great Times"],
    ["address", "705 W. Cross St., Ypsilanti, MI 48197"],
    ["phone", PHONE_DISPLAY],
    ["email", ""],
    ["owner_name", "Vince Ankawi"],
    ["opened_on", "2026-10-02"],
    ["former_venue", "Wurst Bar"],
    ["cuisine_summary", "Elevated fresh lunch and dinner: burgers, salads, soups, seafood, vegetarian. EMU / sports crowd."],
    ["promo_headline", "Good Food, Great Times"],
    ["promo_body", LUNCH_PROMO_BODY],
    ["promo_link_label", ""],
    ["promo_link_url", ""],
    ["toast_ordering_url", ORDER_URL],
    ["reservation_provider", "none"],
    ["reservation_url", ""],
  ];

  const seed = db.transaction(() => {
    for (const [key, value] of settings) insertSetting.run(key, value);
    const insertHour = db.prepare(
      "INSERT INTO hours (label, opens, closes, confirmed, sort_order) VALUES (?, ?, ?, 0, ?)",
    );
    insertHour.run("Sunday–Wednesday", "11:00", "23:00", 10);
    insertHour.run("Thursday–Saturday", "11:00", "00:00", 20);

    insertLunchMenu(db);

    const insertEvent = db.prepare(
      "INSERT INTO events (title, starts_at, blurb, is_sample) VALUES (?, ?, ?, 1)",
    );
    insertEvent.run(
      "Sample: Thursday night",
      "2026-11-21T19:00",
      "Placeholder event so this page is not empty. Not a real booking at Vinny’s.",
    );
    insertEvent.run(
      "Sample: weekend gathering",
      "2026-11-28T16:00",
      "Placeholder event so this page is not empty. Not a real booking at Vinny’s.",
    );
    insertEvent.run(
      "Sample: private hold",
      "2026-12-05T18:00",
      "Placeholder event so this page is not empty. Not a real booking at Vinny’s.",
    );

    db.prepare("INSERT INTO meta (key, value) VALUES ('seeded', '1')").run();
    db.prepare("INSERT INTO meta (key, value) VALUES ('menu_version', '2')").run();
  });
  seed();
  confirmKnownFacts(db);
}

function confirmKnownFacts(db: Database.Database) {
  const phone = db.prepare("SELECT value FROM settings WHERE key = 'phone'").get() as
    | { value: string }
    | undefined;
  const digits = (phone?.value ?? "").replace(/\D/g, "");
  if (!digits || digits === "7349057051" || digits === "17349057051") {
    db.prepare("UPDATE settings SET value = ?, confirmed = 1 WHERE key = 'phone'").run(PHONE_DISPLAY);
  }
  const toast = db.prepare("SELECT value FROM settings WHERE key = 'toast_ordering_url'").get() as
    | { value: string }
    | undefined;
  if (!toast?.value.trim()) {
    db.prepare("UPDATE settings SET value = ? WHERE key = 'toast_ordering_url'").run(ORDER_URL);
  }
}

function ensureEventColumns(db: Database.Database) {
  const columns = db.prepare("PRAGMA table_info(events)").all() as { name: string }[];
  const names = new Set(columns.map((column) => column.name));
  if (!names.has("price")) db.exec("ALTER TABLE events ADD COLUMN price TEXT NOT NULL DEFAULT ''");
  if (!names.has("photo")) db.exec("ALTER TABLE events ADD COLUMN photo TEXT NOT NULL DEFAULT ''");
  if (!names.has("next_step")) db.exec("ALTER TABLE events ADD COLUMN next_step TEXT NOT NULL DEFAULT ''");
}

function ensureMenuColumns(db: Database.Database) {
  const columns = db.prepare("PRAGMA table_info(menu_items)").all() as { name: string }[];
  const names = new Set(columns.map((column) => column.name));
  if (!names.has("gluten_free")) {
    db.exec("ALTER TABLE menu_items ADD COLUMN gluten_free INTEGER NOT NULL DEFAULT 0");
  }
  if (!names.has("marked")) {
    db.exec("ALTER TABLE menu_items ADD COLUMN marked INTEGER NOT NULL DEFAULT 0");
  }
}

function insertLunchMenu(db: Database.Database) {
  const insertSection = db.prepare(
    "INSERT INTO menu_sections (name, blurb, sort_order) VALUES (?, ?, ?)",
  );
  const insertItem = db.prepare(
    `INSERT INTO menu_items
      (section_id, name, description, price, sort_order, is_sample, gluten_free, marked)
     VALUES (?, ?, ?, ?, ?, 0, ?, ?)`,
  );
  LUNCH_MENU.forEach((section, sectionIndex) => {
    const sectionId = Number(
      insertSection.run(section.name, section.blurb, (sectionIndex + 1) * 10).lastInsertRowid,
    );
    section.items.forEach((item, itemIndex) => {
      insertItem.run(
        sectionId,
        item.name,
        item.description,
        item.price,
        (itemIndex + 1) * 10,
        item.glutenFree ? 1 : 0,
        item.marked ? 1 : 0,
      );
    });
  });
}

function replaceLunchMenu(db: Database.Database) {
  const version = db.prepare("SELECT value FROM meta WHERE key = 'menu_version'").get() as
    | { value: string }
    | undefined;
  if (version?.value === "2") return;
  const tx = db.transaction(() => {
    db.prepare("DELETE FROM menu_items").run();
    db.prepare("DELETE FROM menu_sections").run();
    insertLunchMenu(db);
    const promo = db.prepare("SELECT value FROM settings WHERE key = 'promo_body'").get() as
      | { value: string }
      | undefined;
    if (promo?.value === PREVIOUS_PROMO_BODY) {
      db.prepare("UPDATE settings SET value = ? WHERE key = 'promo_body'").run(LUNCH_PROMO_BODY);
    }
    db.prepare(
      `INSERT INTO meta (key, value) VALUES ('menu_version', '2')
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    ).run();
  });
  tx();
}

export function getDb(): Database.Database {
  if (onPublicDeploy()) {
    throw new Error("SQLite is not used on the public site.");
  }
  if (!globalForDb.vinnysDb) {
    const dir = path.join(process.cwd(), "data");
    fs.mkdirSync(dir, { recursive: true });
    const imported = nodeRequire("better-sqlite3") as
      | typeof import("better-sqlite3")
      | { default: typeof import("better-sqlite3") };
    const Sqlite = typeof imported === "function" ? imported : imported.default;
    const db = new Sqlite(path.join(dir, "site.sqlite"));
    db.pragma("journal_mode = WAL");
    db.pragma("foreign_keys = ON");
    db.pragma("busy_timeout = 4000");
    migrate(db);
    globalForDb.vinnysDb = db;
  }
  return globalForDb.vinnysDb;
}

export function getSettings(): SettingsMap {
  if (onPublicDeploy()) {
    const map = Object.fromEntries(
      SETTING_KEYS.map((key) => [key, publicSnapshot.settings[key] ?? { value: "", confirmed: false }]),
    ) as SettingsMap;
    return map;
  }
  const rows = getDb().prepare("SELECT key, value, confirmed FROM settings").all() as SettingRow[];
  const map = Object.fromEntries(
    SETTING_KEYS.map((key) => [key, { value: "", confirmed: false }]),
  ) as SettingsMap;
  for (const row of rows) {
    if ((SETTING_KEYS as readonly string[]).includes(row.key)) {
      map[row.key as SettingKey] = { value: row.value, confirmed: row.confirmed === 1 };
    }
  }
  return map;
}

export function saveSetting(key: SettingKey, value: string, confirmed: boolean) {
  getDb()
    .prepare(
      `INSERT INTO settings (key, value, confirmed) VALUES (?, ?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, confirmed = excluded.confirmed`,
    )
    .run(key, value, confirmed ? 1 : 0);
}

function mapHour(row: HourRow): Hour {
  return { ...row, confirmed: row.confirmed === 1 };
}

export function listHours(): Hour[] {
  if (onPublicDeploy()) return publicSnapshot.hours;
  const rows = getDb()
    .prepare("SELECT id, label, opens, closes, confirmed, sort_order FROM hours ORDER BY sort_order, id")
    .all() as HourRow[];
  return rows.map(mapHour);
}

export function updateHour(row: {
  id: number;
  label: string;
  opens: string;
  closes: string;
  confirmed: boolean;
}) {
  getDb()
    .prepare("UPDATE hours SET label = ?, opens = ?, closes = ?, confirmed = ? WHERE id = ?")
    .run(row.label, row.opens, row.closes, row.confirmed ? 1 : 0, row.id);
}

export function addHour(label: string, opens: string, closes: string) {
  const max = getDb().prepare("SELECT COALESCE(MAX(sort_order), 0) AS m FROM hours").get() as { m: number };
  getDb()
    .prepare("INSERT INTO hours (label, opens, closes, confirmed, sort_order) VALUES (?, ?, ?, 0, ?)")
    .run(label, opens, closes, max.m + 10);
}

export function deleteHour(id: number) {
  getDb().prepare("DELETE FROM hours WHERE id = ?").run(id);
}

export function moveHour(id: number, direction: "up" | "down") {
  const rows = listHours();
  reorder(rows, id, direction, (rowId, sort) => {
    getDb().prepare("UPDATE hours SET sort_order = ? WHERE id = ?").run(sort, rowId);
  });
}

export function listMenu(): MenuSection[] {
  if (onPublicDeploy()) return publicSnapshot.menu;
  const db = getDb();
  const sections = db
    .prepare("SELECT id, name, blurb, sort_order FROM menu_sections ORDER BY sort_order, id")
    .all() as SectionRow[];
  const items = db
    .prepare(
      "SELECT id, section_id, name, description, price, sort_order, is_sample, gluten_free, marked FROM menu_items ORDER BY sort_order, id",
    )
    .all() as ItemRow[];
  return sections.map((section) => ({
    ...section,
    items: items
      .filter((item) => item.section_id === section.id)
      .map((item) => ({
        ...item,
        is_sample: item.is_sample === 1,
        gluten_free: item.gluten_free === 1,
        marked: item.marked === 1,
      })),
  }));
}

export function addSection(name: string, blurb: string) {
  const max = getDb()
    .prepare("SELECT COALESCE(MAX(sort_order), 0) AS m FROM menu_sections")
    .get() as { m: number };
  getDb()
    .prepare("INSERT INTO menu_sections (name, blurb, sort_order) VALUES (?, ?, ?)")
    .run(name, blurb, max.m + 10);
}

export function updateSection(id: number, name: string, blurb: string) {
  getDb().prepare("UPDATE menu_sections SET name = ?, blurb = ? WHERE id = ?").run(name, blurb, id);
}

export function deleteSection(id: number) {
  getDb().prepare("DELETE FROM menu_sections WHERE id = ?").run(id);
}

export function moveSection(id: number, direction: "up" | "down") {
  const rows = getDb()
    .prepare("SELECT id, sort_order FROM menu_sections ORDER BY sort_order, id")
    .all() as { id: number; sort_order: number }[];
  reorder(rows, id, direction, (rowId, sort) => {
    getDb().prepare("UPDATE menu_sections SET sort_order = ? WHERE id = ?").run(sort, rowId);
  });
}

export function addItem(input: {
  sectionId: number;
  name: string;
  description: string;
  price: string;
  isSample: boolean;
}) {
  const max = getDb()
    .prepare("SELECT COALESCE(MAX(sort_order), 0) AS m FROM menu_items WHERE section_id = ?")
    .get(input.sectionId) as { m: number };
  getDb()
    .prepare(
      "INSERT INTO menu_items (section_id, name, description, price, sort_order, is_sample) VALUES (?, ?, ?, ?, ?, ?)",
    )
    .run(
      input.sectionId,
      input.name,
      input.description,
      input.price,
      max.m + 10,
      input.isSample ? 1 : 0,
    );
}

export function updateItem(input: {
  id: number;
  sectionId: number;
  name: string;
  description: string;
  price: string;
  isSample: boolean;
}) {
  const db = getDb();
  const current = db.prepare("SELECT section_id FROM menu_items WHERE id = ?").get(input.id) as
    | { section_id: number }
    | undefined;
  if (!current) return;
  if (current.section_id !== input.sectionId) {
    const max = db
      .prepare("SELECT COALESCE(MAX(sort_order), 0) AS m FROM menu_items WHERE section_id = ?")
      .get(input.sectionId) as { m: number };
    db.prepare(
      "UPDATE menu_items SET section_id = ?, name = ?, description = ?, price = ?, is_sample = ?, sort_order = ? WHERE id = ?",
    ).run(
      input.sectionId,
      input.name,
      input.description,
      input.price,
      input.isSample ? 1 : 0,
      max.m + 10,
      input.id,
    );
    return;
  }
  db.prepare(
    "UPDATE menu_items SET name = ?, description = ?, price = ?, is_sample = ? WHERE id = ?",
  ).run(input.name, input.description, input.price, input.isSample ? 1 : 0, input.id);
}

export function deleteItem(id: number) {
  getDb().prepare("DELETE FROM menu_items WHERE id = ?").run(id);
}

export function moveItem(id: number, direction: "up" | "down") {
  const current = getDb().prepare("SELECT section_id FROM menu_items WHERE id = ?").get(id) as
    | { section_id: number }
    | undefined;
  if (!current) return;
  const rows = getDb()
    .prepare(
      "SELECT id, sort_order FROM menu_items WHERE section_id = ? ORDER BY sort_order, id",
    )
    .all(current.section_id) as { id: number; sort_order: number }[];
  reorder(rows, id, direction, (rowId, sort) => {
    getDb().prepare("UPDATE menu_items SET sort_order = ? WHERE id = ?").run(sort, rowId);
  });
}

function asEvent(row: EventRow): EventRow {
  return {
    id: row.id,
    title: row.title,
    starts_at: row.starts_at,
    blurb: row.blurb,
    is_sample: Boolean(row.is_sample),
    price: row.price ?? "",
    photo: row.photo ?? "",
    next_step: row.next_step ?? "",
  };
}

export function listEvents(): EventRow[] {
  if (onPublicDeploy()) return publicSnapshot.events.map((row) => asEvent(row));
  const rows = getDb()
    .prepare(
      "SELECT id, title, starts_at, blurb, is_sample, price, photo, next_step FROM events ORDER BY starts_at, id",
    )
    .all() as EventDbRow[];
  return rows.map((row) => asEvent({ ...row, is_sample: row.is_sample === 1 }));
}

export function addEvent(input: {
  title: string;
  startsAt: string;
  blurb: string;
  isSample: boolean;
  price: string;
  photo: string;
  nextStep: string;
}) {
  getDb()
    .prepare(
      "INSERT INTO events (title, starts_at, blurb, is_sample, price, photo, next_step) VALUES (?, ?, ?, ?, ?, ?, ?)",
    )
    .run(
      input.title,
      input.startsAt,
      input.blurb,
      input.isSample ? 1 : 0,
      input.price,
      input.photo,
      input.nextStep,
    );
}

export function updateEvent(input: {
  id: number;
  title: string;
  startsAt: string;
  blurb: string;
  isSample: boolean;
  price: string;
  photo: string;
  nextStep: string;
}) {
  getDb()
    .prepare(
      "UPDATE events SET title = ?, starts_at = ?, blurb = ?, is_sample = ?, price = ?, photo = ?, next_step = ? WHERE id = ?",
    )
    .run(
      input.title,
      input.startsAt,
      input.blurb,
      input.isSample ? 1 : 0,
      input.price,
      input.photo,
      input.nextStep,
      input.id,
    );
}

export function deleteEvent(id: number) {
  getDb().prepare("DELETE FROM events WHERE id = ?").run(id);
}

export function listInquiries(): Inquiry[] {
  return getDb()
    .prepare(
      "SELECT id, name, email, event_date, party_size, message, created_at FROM inquiries ORDER BY created_at DESC, id DESC",
    )
    .all() as Inquiry[];
}

export async function addInquiry(input: {
  name: string;
  email: string;
  eventDate: string;
  partySize: number;
  message: string;
}) {
  const createdAt = new Date().toISOString();
  if (onPublicDeploy()) {
    const { insertInquiry } = await import("./d1-write");
    await insertInquiry({ ...input, createdAt });
    return;
  }
  getDb()
    .prepare(
      "INSERT INTO inquiries (name, email, event_date, party_size, message, created_at) VALUES (?, ?, ?, ?, ?, ?)",
    )
    .run(
      input.name,
      input.email,
      input.eventDate,
      input.partySize,
      input.message,
      createdAt,
    );
}

export function deleteInquiry(id: number) {
  getDb().prepare("DELETE FROM inquiries WHERE id = ?").run(id);
}

export type Signup = {
  id: number;
  email: string;
  created_at: string;
};

export async function addSignup(email: string) {
  const createdAt = new Date().toISOString();
  if (onPublicDeploy()) {
    const { insertSignup } = await import("./d1-write");
    await insertSignup(email, createdAt);
    return;
  }
  getDb().prepare("INSERT INTO signups (email, created_at) VALUES (?, ?)").run(email, createdAt);
}

export function listSignups(): Signup[] {
  return getDb()
    .prepare("SELECT id, email, created_at FROM signups ORDER BY created_at DESC, id DESC")
    .all() as Signup[];
}

export function sectionExists(id: number): boolean {
  const row = getDb().prepare("SELECT id FROM menu_sections WHERE id = ?").get(id);
  return Boolean(row);
}

function reorder(
  rows: { id: number; sort_order: number }[],
  id: number,
  direction: "up" | "down",
  apply: (id: number, sort: number) => void,
) {
  const index = rows.findIndex((row) => row.id === id);
  const swapWith = index + (direction === "up" ? -1 : 1);
  if (index < 0 || swapWith < 0 || swapWith >= rows.length) return;
  const next = rows.slice();
  const [row] = next.splice(index, 1);
  next.splice(swapWith, 0, row);
  const db = getDb();
  const tx = db.transaction(() => {
    next.forEach((item, itemIndex) => apply(item.id, (itemIndex + 1) * 10));
  });
  tx();
}

export type { MenuItem };
