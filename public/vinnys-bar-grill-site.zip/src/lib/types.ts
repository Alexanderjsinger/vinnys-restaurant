export const SETTING_KEYS = [
  "restaurant_name",
  "tagline",
  "address",
  "phone",
  "email",
  "owner_name",
  "opened_on",
  "former_venue",
  "cuisine_summary",
  "promo_headline",
  "promo_body",
  "promo_link_label",
  "promo_link_url",
  "toast_ordering_url",
  "reservation_provider",
  "reservation_url",
] as const;

export type SettingKey = (typeof SETTING_KEYS)[number];

export type Setting = {
  value: string;
  confirmed: boolean;
};

export type SettingsMap = Record<SettingKey, Setting>;

export type ProviderId = "none" | "toast" | "opentable" | "resy";

export type Hour = {
  id: number;
  label: string;
  opens: string;
  closes: string;
  confirmed: boolean;
  sort_order: number;
};

export type MenuItem = {
  id: number;
  section_id: number;
  name: string;
  description: string;
  price: string;
  sort_order: number;
  is_sample: boolean;
  gluten_free: boolean;
  marked: boolean;
};

export type MenuSection = {
  id: number;
  name: string;
  blurb: string;
  sort_order: number;
  items: MenuItem[];
};

export type EventRow = {
  id: number;
  title: string;
  starts_at: string;
  blurb: string;
  is_sample: boolean;
  price: string;
  photo: string;
  next_step: string;
};

export type Inquiry = {
  id: number;
  name: string;
  email: string;
  event_date: string;
  party_size: number;
  message: string;
  created_at: string;
};

export type StoryFact = {
  label: string;
  value: string;
};

export type PublicSite = {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  phoneHref: string | null;
  email: string;
  mapUrl: string | null;
  hours: Hour[];
  promo: {
    headline: string;
    body: string;
    linkLabel: string;
    linkUrl: string | null;
  };
  toastUrl: string | null;
  reservation: {
    provider: ProviderId;
    url: string | null;
    ready: boolean;
  };
  story: StoryFact[];
};

export type PartyDraft = {
  name: string;
  email: string;
  event_date: string;
  party_size: string;
  message: string;
};
