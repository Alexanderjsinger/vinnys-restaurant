import "server-only";
import { connection } from "next/server";
import { getSettings, listHours } from "./db";
import { formatLongDate, mapUrl, parseProvider, phoneHref, safeHttpUrl } from "./format";
import type { PublicSite, StoryFact } from "./types";

export async function getSite(): Promise<PublicSite> {
  await connection();
  const settings = getSettings();
  const provider = parseProvider(settings.reservation_provider.value);
  const reservationUrl = safeHttpUrl(settings.reservation_url.value);
  const story: StoryFact[] = [];

  if (settings.owner_name.confirmed && settings.owner_name.value.trim()) {
    story.push({ label: "Owner", value: settings.owner_name.value.trim() });
  }
  if (settings.opened_on.confirmed && settings.opened_on.value.trim()) {
    story.push({ label: "Opened", value: formatLongDate(settings.opened_on.value.trim()) });
  }
  if (settings.former_venue.confirmed && settings.former_venue.value.trim()) {
    story.push({ label: "Formerly", value: settings.former_venue.value.trim() });
  }
  if (settings.cuisine_summary.confirmed && settings.cuisine_summary.value.trim()) {
    story.push({ label: "Kitchen", value: settings.cuisine_summary.value.trim() });
  }

  return {
    name: settings.restaurant_name.value.trim() || "Vinny's Bar & Grill",
    tagline: settings.tagline.value.trim(),
    address: settings.address.value.trim(),
    phone: settings.phone.value.trim(),
    phoneHref: phoneHref(settings.phone.value),
    email: settings.email.value.trim(),
    mapUrl: mapUrl(settings.address.value),
    hours: listHours(),
    promo: {
      headline: settings.promo_headline.value.trim(),
      body: settings.promo_body.value.trim(),
      linkLabel: settings.promo_link_label.value.trim(),
      linkUrl: safeHttpUrl(settings.promo_link_url.value),
    },
    toastUrl: safeHttpUrl(settings.toast_ordering_url.value),
    reservation: {
      provider,
      url: reservationUrl,
      ready: provider !== "none" && reservationUrl !== null,
    },
    story,
  };
}
