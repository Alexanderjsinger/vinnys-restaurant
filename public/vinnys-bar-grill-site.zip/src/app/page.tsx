import Link from "next/link";
import { ConfirmedEvents } from "@/components/ConfirmedEvents";
import { PosterSlider } from "@/components/PosterSlider";
import { HoursList } from "@/components/HoursList";
import { detroitToday, eventDate, formatPrice } from "@/lib/format";
import { firstQuery } from "@/lib/messages";
import { listEvents, listMenu } from "@/lib/db";
import { LUNCH_SERVICE } from "@/lib/lunch-menu";
import { listEventPosters } from "@/lib/posters";
import {
  BIRTHDAY_ACTION,
  BIRTHDAY_HEADING,
  DIRECTIONS_URL,
  MAP_QUERY,
  ORDER_URL,
  PHONE_DISPLAY,
  RESERVE_TEL,
} from "@/lib/public";
import { LUNCH_PLATES } from "@/lib/lunch-photos";
import { pageMeta } from "@/lib/seo";
import { getSite } from "@/lib/site";
import type { MenuItem } from "@/lib/types";

export const metadata = pageMeta(
  "/",
  { absolute: "Vinny's Bar & Grill" },
  "Vinny's Bar & Grill is a bar and grill across from EMU at 705 W. Cross St., Ypsilanti. Lunch is served daily, 11–3pm.",
);

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const HIGHLIGHT_NAMES = [
  "VINNY'S BURGER",
  "SPICY CAULIFLOWER",
  "SOUTHERN CHICKEN SALAD",
  "WINGS (8)",
  "FRENCH DIP",
  "BAVARIAN PRETZEL",
];

function lunchPlates(): { plate: (typeof LUNCH_PLATES)[number]; item: MenuItem }[] {
  const items = listMenu()
    .flatMap((section) => section.items)
    .filter((item) => !item.is_sample);
  return LUNCH_PLATES.flatMap((plate) => {
    const item = items.find((row) => row.name === plate.menuName);
    return item ? [{ plate, item }] : [];
  });
}

function lunchHighlights(): MenuItem[] {
  const items = listMenu()
    .flatMap((section) => section.items)
    .filter((item) => !item.is_sample);
  return HIGHLIGHT_NAMES.flatMap((name) => {
    const match = items.find((item) => item.name === name);
    return match ? [match] : [];
  });
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const joined = firstQuery(query.joined) === "1";
  const joinCode = firstQuery(query.join);
  const joinError = joinCode === "email" || joinCode === "save";
  const site = await getSite();
  const posters = listEventPosters();
  const plates = lunchPlates();
  const highlights = lunchHighlights();
  const today = detroitToday();
  const upcoming = listEvents()
    .filter((event) => !event.is_sample && eventDate(event.starts_at) >= today)
    .slice(0, 3);
  const mapSrc = `https://maps.google.com/maps?q=${encodeURIComponent(MAP_QUERY)}&z=16&output=embed`;

  return (
    <>
      <PosterSlider posters={posters} />

      <section className="page wrap home-intro" aria-labelledby="home-heading">
        <h1 id="home-heading">Vinny&apos;s Bar &amp; Grill</h1>
        <p className="lede">
          A bar and grill across from EMU in Ypsilanti. Lunch is served daily, 11–3pm, from the printed menu.
        </p>
        <div className="cta-row">
          <Link className="btn btn-solid" href="/menu">
            View Menu
          </Link>
          <a className="btn" href={site.mapUrl || DIRECTIONS_URL} data-track="directions_click" target="_blank" rel="noopener noreferrer">
            Get Directions
            <span className="sr-only"> (opens in a new tab)</span>
          </a>
          <a className="btn" href={site.phoneHref || RESERVE_TEL} data-track="phone_click">
            {site.phone || PHONE_DISPLAY}
          </a>
        </div>
      </section>

      <section className="page wrap" aria-labelledby="plates-heading">
        <h2 id="plates-heading">Lunch plates</h2>
        <ul className="plate-list">
          {plates.map(({ plate, item }) => (
            <li key={item.id} className="plate">
              <figure className="shot">
                <img src={plate.src} alt={plate.alt} width={plate.width} height={plate.height} />
              </figure>
              <h3>{item.name}</h3>
              {item.description ? <p>{item.description}</p> : null}
              <p className="price">{formatPrice(item.price)}</p>
            </li>
          ))}
        </ul>
      </section>

      <figure className="venue-shot">
        <img
          src="/photos/storefront.webp"
          alt="Exterior of Vinny's Bar & Grill at 705 W. Cross St."
          width={1110}
          height={886}
        />
        <figcaption>
          Storefront at 705 W. Cross St. This is a listing photo of the exterior, not an owner photo of the dining room.
        </figcaption>
      </figure>

      <section className="page wrap home-cards" aria-label="Lunch, events, and private parties">
        <article className="home-card">
          <h2>Lunch</h2>
          <p className="lunch-line">{LUNCH_SERVICE}</p>
          <ul className="highlights">
            {highlights.map((item) => (
              <li key={item.id}>
                <span>
                  {item.name}
                  {item.description ? <small>{item.description}</small> : null}
                </span>
                <span className="price">{formatPrice(item.price)}</span>
              </li>
            ))}
          </ul>
          <Link className="btn" href="/menu">
            Full lunch menu
          </Link>
        </article>

        <article className="home-card">
          <h2>Events</h2>
          <ConfirmedEvents events={upcoming} />
          <Link className="btn" href="/events">
            Events
          </Link>
        </article>

        <article className="home-card">
          <h2>Private parties</h2>
          <p>Call to plan a private party.</p>
          <a className="btn btn-solid" href={site.phoneHref || RESERVE_TEL} data-track="phone_click">
            {site.phone || PHONE_DISPLAY}
          </a>
        </article>
      </section>

      <section className="visit-band" aria-labelledby="visit-heading">
        <div className="wrap visit-grid">
          <div>
            <h2 id="visit-heading">Visit</h2>
            <p className="lunch-line">{LUNCH_SERVICE}</p>
            <HoursList hours={site.hours} />
            <p className="visit-address">{site.address || MAP_QUERY}</p>
            <p>
              <a href={site.phoneHref || RESERVE_TEL} data-track="phone_click">
                {site.phone || PHONE_DISPLAY}
              </a>
            </p>
            <p>
              <a href={site.mapUrl || DIRECTIONS_URL} data-track="directions_click" target="_blank" rel="noopener noreferrer">
                Get Directions
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            </p>
            <p>
              <a className="btn btn-solid" href={site.toastUrl || ORDER_URL} target="_blank" rel="noopener noreferrer">
                Order
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            </p>
          </div>
          <iframe
            className="visit-map"
            title="Map of Vinny's Bar & Grill at 705 W. Cross St., Ypsilanti"
            src={mapSrc}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

      <section className="signup-band" id="list" aria-labelledby="list-heading">
        <div className="wrap">
          <h2 id="list-heading">{BIRTHDAY_HEADING}</h2>
          <p>{BIRTHDAY_ACTION}</p>
          {joined ? (
            <p className="banner banner-good" role="status">
              You&apos;re on the list.
            </p>
          ) : null}
          {joinError ? (
            <p className="banner banner-bad" role="alert">
              {joinCode === "save" ? "That signup did not save. Call the restaurant and try again." : "Enter a valid email."}
            </p>
          ) : null}
          <form className="signup-form" action="/api/signup" method="post">
            <div className="hp" aria-hidden="true">
              <label>
                Company website
                <input name="company_website" tabIndex={-1} autoComplete="off" />
              </label>
            </div>
            <label className="sr-only" htmlFor="list-email">
              Email
            </label>
            <input
              id="list-email"
              name="email"
              type="email"
              autoComplete="email"
              required
              placeholder="Email"
            />
            <button className="btn btn-solid" type="submit">
              {BIRTHDAY_ACTION}
            </button>
          </form>
        </div>
      </section>
    </>
  );
}
