import { redirect } from "next/navigation";
import { ORDER_URL } from "@/lib/public";
import { getSite } from "@/lib/site";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function OrderPage() {
  const site = await getSite();
  redirect(site.toastUrl || ORDER_URL);
}
