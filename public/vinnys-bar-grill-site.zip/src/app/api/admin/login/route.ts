import { NextResponse } from "next/server";
import { cookieBase, SESSION_COOKIE, SESSION_MAX_AGE, checkPassword, sessionCookieValue } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const form = await request.formData();
  const password = String(form.get("password") ?? "");
  const ok = await checkPassword(password);
  if (!ok) {
    return NextResponse.redirect(new URL("/admin/login?error=1", request.url), 303);
  }
  const token = await sessionCookieValue();
  if (!token) {
    return NextResponse.redirect(new URL("/admin/login?error=config", request.url), 303);
  }
  const response = NextResponse.redirect(new URL("/admin", request.url), 303);
  response.cookies.set(SESSION_COOKIE, token, {
    ...(await cookieBase()),
    maxAge: SESSION_MAX_AGE,
  });
  return response;
}
