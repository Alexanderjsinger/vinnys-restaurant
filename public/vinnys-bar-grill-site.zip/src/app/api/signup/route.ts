import { NextResponse } from "next/server";
import { addSignup } from "@/lib/db";
import { isEmail, sameOriginPost } from "@/lib/format";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOriginPost(request)) {
    return NextResponse.redirect(new URL("/?joined=1#list", request.url), 303);
  }
  const form = await request.formData();
  if (String(form.get("company_website") ?? "").trim()) {
    return NextResponse.redirect(new URL("/?joined=1#list", request.url), 303);
  }
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  if (!isEmail(email)) {
    return NextResponse.redirect(new URL("/?join=email#list", request.url), 303);
  }
  try {
    await addSignup(email);
  } catch {
    return NextResponse.redirect(new URL("/?join=save#list", request.url), 303);
  }
  return NextResponse.redirect(new URL("/?joined=1#list", request.url), 303);
}
