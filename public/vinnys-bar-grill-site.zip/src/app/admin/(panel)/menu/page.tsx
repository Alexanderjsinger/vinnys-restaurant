import { SaveBanner } from "@/components/SaveBanner";
import { listMenu } from "@/lib/db";
import { firstQuery } from "@/lib/messages";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function MenuAdminPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const menu = listMenu();
  return (
    <>
      <h1>Menu</h1>
      <SaveBanner saved={firstQuery(query.saved)} error={firstQuery(query.error)} />
      <p>
        The lunch menu is the printed menu, served daily 11–3pm. Those items are real. Gluten-free
        marks and asterisks come from that menu. Leave “Sample placeholder” unchecked unless you add
        a stand-in.
      </p>
      {menu.map((section) => (
        <article key={section.id} className="item-card">
          <form className="form-grid" action="/api/admin/save" method="post">
            <input type="hidden" name="intent" value="section-update" />
            <input type="hidden" name="id" value={section.id} />
            <div className="field">
              <label htmlFor={`section-name-${section.id}`}>Section name</label>
              <input id={`section-name-${section.id}`} name="name" defaultValue={section.name} required />
            </div>
            <div className="field">
              <label htmlFor={`section-blurb-${section.id}`}>Section note</label>
              <input id={`section-blurb-${section.id}`} name="blurb" defaultValue={section.blurb} />
            </div>
            <button className="btn" type="submit">
              Save section
            </button>
          </form>
          <div className="row-actions">
            <form action="/api/admin/save" method="post">
              <input type="hidden" name="intent" value="section-move" />
              <input type="hidden" name="id" value={section.id} />
              <input type="hidden" name="dir" value="up" />
              <button className="btn btn-small" type="submit">
                Move section up
              </button>
            </form>
            <form action="/api/admin/save" method="post">
              <input type="hidden" name="intent" value="section-move" />
              <input type="hidden" name="id" value={section.id} />
              <input type="hidden" name="dir" value="down" />
              <button className="btn btn-small" type="submit">
                Move section down
              </button>
            </form>
            <form action="/api/admin/save" method="post">
              <input type="hidden" name="intent" value="section-delete" />
              <input type="hidden" name="id" value={section.id} />
              <label className="check">
                <input type="checkbox" name="yes" value="1" required />
                Delete this section and its items
              </label>
              <button className="btn btn-small btn-danger" type="submit">
                Delete section
              </button>
            </form>
          </div>
          {section.items.map((item) => (
            <form key={item.id} className="form-grid item-card" action="/api/admin/save" method="post">
              <input type="hidden" name="intent" value="item-update" />
              <input type="hidden" name="id" value={item.id} />
              {item.is_sample ? <span className="badge badge-warn">Sample</span> : null}
              <div className="field">
                <label htmlFor={`item-name-${item.id}`}>Item name</label>
                <input id={`item-name-${item.id}`} name="name" defaultValue={item.name} required />
              </div>
              <div className="field">
                <label htmlFor={`item-desc-${item.id}`}>Description</label>
                <textarea id={`item-desc-${item.id}`} name="description" defaultValue={item.description} />
              </div>
              <div className="split">
                <div className="field">
                  <label htmlFor={`item-price-${item.id}`}>Price</label>
                  <input id={`item-price-${item.id}`} name="price" defaultValue={item.price} required />
                </div>
                <div className="field">
                  <label htmlFor={`item-section-${item.id}`}>Section</label>
                  <select id={`item-section-${item.id}`} name="section_id" defaultValue={item.section_id}>
                    {menu.map((option) => (
                      <option key={option.id} value={option.id}>
                        {option.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <label className="check" htmlFor={`item-sample-${item.id}`}>
                <input
                  id={`item-sample-${item.id}`}
                  type="checkbox"
                  name="is_sample"
                  defaultChecked={item.is_sample}
                />
                Sample placeholder
              </label>
              <button className="btn" type="submit">
                Save item
              </button>
            </form>
          ))}
          {section.items.map((item) => (
            <div key={`move-${item.id}`} className="row-actions">
              <form action="/api/admin/save" method="post">
                <input type="hidden" name="intent" value="item-move" />
                <input type="hidden" name="id" value={item.id} />
                <input type="hidden" name="dir" value="up" />
                <button className="btn btn-small" type="submit">
                  Move {item.name} up
                </button>
              </form>
              <form action="/api/admin/save" method="post">
                <input type="hidden" name="intent" value="item-move" />
                <input type="hidden" name="id" value={item.id} />
                <input type="hidden" name="dir" value="down" />
                <button className="btn btn-small" type="submit">
                  Move {item.name} down
                </button>
              </form>
              <form action="/api/admin/save" method="post">
                <input type="hidden" name="intent" value="item-delete" />
                <input type="hidden" name="id" value={item.id} />
                <label className="check">
                  <input type="checkbox" name="yes" value="1" required />
                  Delete {item.name}
                </label>
                <button className="btn btn-small btn-danger" type="submit">
                  Delete item
                </button>
              </form>
            </div>
          ))}
          <h3>Add item to {section.name}</h3>
          <form className="form-grid" action="/api/admin/save" method="post">
            <input type="hidden" name="intent" value="item-add" />
            <input type="hidden" name="section_id" value={section.id} />
            <div className="field">
              <label htmlFor={`add-name-${section.id}`}>Item name</label>
              <input id={`add-name-${section.id}`} name="name" required />
            </div>
            <div className="field">
              <label htmlFor={`add-desc-${section.id}`}>Description</label>
              <textarea id={`add-desc-${section.id}`} name="description" />
            </div>
            <div className="field">
              <label htmlFor={`add-price-${section.id}`}>Price</label>
              <input id={`add-price-${section.id}`} name="price" required />
            </div>
            <label className="check" htmlFor={`add-sample-${section.id}`}>
              <input id={`add-sample-${section.id}`} type="checkbox" name="is_sample" />
              Sample placeholder
            </label>
            <button className="btn" type="submit">
              Add item
            </button>
          </form>
        </article>
      ))}
      <h2>Add section</h2>
      <form className="form-grid" action="/api/admin/save" method="post">
        <input type="hidden" name="intent" value="section-add" />
        <div className="field">
          <label htmlFor="new-section-name">Section name</label>
          <input id="new-section-name" name="name" required />
        </div>
        <div className="field">
          <label htmlFor="new-section-blurb">Section note</label>
          <input id="new-section-blurb" name="blurb" />
        </div>
        <button className="btn btn-solid" type="submit">
          Add section
        </button>
      </form>
    </>
  );
}
