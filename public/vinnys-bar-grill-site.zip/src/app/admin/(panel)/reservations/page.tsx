import { SaveBanner } from "@/components/SaveBanner";
import { getSettings } from "@/lib/db";
import { PROVIDERS, parseProvider, safeHttpUrl } from "@/lib/format";
import { firstQuery } from "@/lib/messages";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function ReservationsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const settings = getSettings();
  const provider = parseProvider(settings.reservation_provider.value);
  const ready = provider !== "none" && Boolean(safeHttpUrl(settings.reservation_url.value));
  return (
    <>
      <h1>Reservations</h1>
      <SaveBanner saved={firstQuery(query.saved)} error={firstQuery(query.error)} />
      <p>
        {ready ? (
          <span className="badge badge-ok">Connected</span>
        ) : provider === "none" ? (
          <span className="badge badge-muted">Provider: none</span>
        ) : (
          <span className="badge badge-warn">Booking link missing</span>
        )}
      </p>
      <p>
        Public Call to reserve dials 734-905-7051. This screen does not change that button. Toast
        Tables, OpenTable, and Resy can be saved here for later.
      </p>
      <form className="form-grid" action="/api/admin/save" method="post">
        <input type="hidden" name="intent" value="reservations" />
        <div className="field">
          <label htmlFor="reservation_provider">Provider</label>
          <select id="reservation_provider" name="reservation_provider" defaultValue={provider}>
            {PROVIDERS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.id === "none" ? "None — not connected" : item.label}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="reservation_url">Booking URL</label>
          <input
            id="reservation_url"
            name="reservation_url"
            type="url"
            defaultValue={settings.reservation_url.value}
            placeholder="https://"
          />
          <p className="hint">The public Reserve button uses this URL once a provider is selected.</p>
        </div>
        <button className="btn btn-solid" type="submit">
          Save reservations
        </button>
      </form>
    </>
  );
}
