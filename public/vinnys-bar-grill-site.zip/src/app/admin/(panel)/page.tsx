import Link from "next/link";
import { SaveBanner } from "@/components/SaveBanner";
import { StatusBadge } from "@/components/StatusBadge";
import { listEvents, listHours, listInquiries, listMenu, listSignups, getSettings } from "@/lib/db";
import { formatTimestamp, providerLabel, parseProvider, safeHttpUrl } from "@/lib/format";
import { firstQuery } from "@/lib/messages";
import type { SettingKey } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const FACTS: { key: SettingKey; label: string; href: string }[] = [
  { key: "restaurant_name", label: "Restaurant name", href: "/admin/place" },
  { key: "address", label: "Address", href: "/admin/place" },
  { key: "phone", label: "Phone", href: "/admin/place" },
  { key: "email", label: "Email", href: "/admin/place" },
  { key: "tagline", label: "Tagline", href: "/admin/story" },
  { key: "owner_name", label: "Owner", href: "/admin/story" },
  { key: "opened_on", label: "Opened", href: "/admin/story" },
  { key: "former_venue", label: "Former venue", href: "/admin/story" },
  { key: "cuisine_summary", label: "Cuisine notes", href: "/admin/story" },
];

export default async function AdminHome({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const settings = getSettings();
  const hours = listHours();
  const menu = listMenu();
  const events = listEvents();
  const inquiries = listInquiries();
  const signups = listSignups();
  const sampleItems = menu.reduce(
    (count, section) => count + section.items.filter((item) => item.is_sample).length,
    0,
  );
  const sampleEvents = events.filter((event) => event.is_sample).length;
  const provider = parseProvider(settings.reservation_provider.value);
  const toast = safeHttpUrl(settings.toast_ordering_url.value);
  const booking = safeHttpUrl(settings.reservation_url.value);

  return (
    <>
      <h1>Overview</h1>
      <SaveBanner saved={firstQuery(query.saved)} error={firstQuery(query.error)} />
      <p>
        Page layout stays in code. Everything below can change without a deploy. Facts from public
        listings start out unconfirmed. Phone, hours, address, name, and tagline can show on the
        public site while the badge still says unconfirmed. Owner, opening date, former venue, and
        cuisine stay hidden until you mark them confirmed.
      </p>
      <div className="path-grid">
        <article className="item-card">
          <h2>Ordering</h2>
          <p>{toast ? "Toast link saved." : "Ordering link not connected yet."}</p>
          <Link href="/admin/ordering">Edit ordering</Link>
        </article>
        <article className="item-card">
          <h2>Reservations</h2>
          <p>
            Provider: {providerLabel(provider)}. {booking ? "Booking link saved." : "No booking link."}
          </p>
          <Link href="/admin/reservations">Edit reservations</Link>
        </article>
        <article className="item-card">
          <h2>Samples and notes</h2>
          <p>
            {sampleItems} sample menu item{sampleItems === 1 ? "" : "s"}. {sampleEvents} sample event
            {sampleEvents === 1 ? "" : "s"}. {inquiries.length} party inquir
            {inquiries.length === 1 ? "y" : "ies"}.
          </p>
          <Link href="/admin/menu">Edit menu</Link>
        </article>
      </div>
      <h2>Birthday list</h2>
      {signups.length ? (
        <ul className="stack">
          {signups.map((signup) => (
            <li key={signup.id}>
              {signup.email} <span className="hint">{formatTimestamp(signup.created_at)}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p>No one has joined the birthday list yet.</p>
      )}
      <h2>Unconfirmed facts</h2>
      <ul className="stack">
        {FACTS.filter((fact) => settings[fact.key].value.trim() && !settings[fact.key].confirmed).map(
          (fact) => (
            <li key={fact.key}>
              <Link href={fact.href}>{fact.label}</Link>{" "}
              <StatusBadge value={settings[fact.key].value} confirmed={false} />
            </li>
          ),
        )}
        {hours
          .filter((hour) => !hour.confirmed)
          .map((hour) => (
            <li key={hour.id}>
              <Link href="/admin/place">Hours: {hour.label}</Link>{" "}
              <span className="badge badge-warn">Unconfirmed</span>
            </li>
          ))}
      </ul>
    </>
  );
}
