import { Field } from "@/components/Field";
import { SaveBanner } from "@/components/SaveBanner";
import { getSettings } from "@/lib/db";
import { firstQuery } from "@/lib/messages";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function StoryPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const settings = getSettings();
  return (
    <>
      <h1>Story</h1>
      <SaveBanner saved={firstQuery(query.saved)} error={firstQuery(query.error)} />
      <p>
        These details came from public listings and the current one-page site. They are unconfirmed.
        The tagline is shown in the footer. Owner, opening date, former venue, and cuisine notes stay
        off the public site until you mark each one confirmed.
      </p>
      <form className="form-grid" action="/api/admin/save" method="post">
        <input type="hidden" name="intent" value="story" />
        <Field
          label="Tagline"
          name="tagline"
          value={settings.tagline.value}
          confirmed={settings.tagline.confirmed}
          hint="Shown in the footer. The current site says “Good Food, Great Times.”"
        />
        <Field
          label="Owner"
          name="owner_name"
          value={settings.owner_name.value}
          confirmed={settings.owner_name.confirmed}
          hint="Hidden on the public site until confirmed."
        />
        <Field
          label="Opened"
          name="opened_on"
          type="date"
          value={settings.opened_on.value}
          confirmed={settings.opened_on.confirmed}
          hint="Hidden on the public site until confirmed."
        />
        <Field
          label="Former venue"
          name="former_venue"
          value={settings.former_venue.value}
          confirmed={settings.former_venue.confirmed}
          hint="Hidden on the public site until confirmed."
        />
        <Field
          label="Cuisine notes"
          name="cuisine_summary"
          value={settings.cuisine_summary.value}
          confirmed={settings.cuisine_summary.confirmed}
          multiline
          hint="Hidden on the public site until confirmed. This is not a menu."
        />
        <button className="btn btn-solid" type="submit">
          Save story
        </button>
      </form>
    </>
  );
}
