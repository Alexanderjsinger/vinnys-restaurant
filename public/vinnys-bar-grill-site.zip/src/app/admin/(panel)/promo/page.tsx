import { SaveBanner } from "@/components/SaveBanner";
import { getSettings } from "@/lib/db";
import { firstQuery } from "@/lib/messages";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function PromoPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const settings = getSettings();
  return (
    <>
      <h1>Home promo</h1>
      <SaveBanner saved={firstQuery(query.saved)} error={firstQuery(query.error)} />
      <p>
        This is the text on the home page. It is copy you control, not a confirmed-fact field. The
        starting headline repeats the current site’s tagline.
      </p>
      <form className="form-grid" action="/api/admin/save" method="post">
        <input type="hidden" name="intent" value="promo" />
        <div className="field">
          <label htmlFor="promo_headline">Headline</label>
          <input
            id="promo_headline"
            name="promo_headline"
            defaultValue={settings.promo_headline.value}
          />
        </div>
        <div className="field">
          <label htmlFor="promo_body">Body</label>
          <textarea id="promo_body" name="promo_body" defaultValue={settings.promo_body.value} />
        </div>
        <div className="field">
          <label htmlFor="promo_link_label">Optional link label</label>
          <input
            id="promo_link_label"
            name="promo_link_label"
            defaultValue={settings.promo_link_label.value}
          />
        </div>
        <div className="field">
          <label htmlFor="promo_link_url">Optional link URL</label>
          <input
            id="promo_link_url"
            name="promo_link_url"
            type="url"
            defaultValue={settings.promo_link_url.value}
            placeholder="https://"
          />
        </div>
        <button className="btn btn-solid" type="submit">
          Save promo
        </button>
      </form>
    </>
  );
}
