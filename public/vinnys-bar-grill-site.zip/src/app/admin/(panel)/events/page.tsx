import { SaveBanner } from "@/components/SaveBanner";
import { listEvents } from "@/lib/db";
import { formatEventStart } from "@/lib/format";
import { firstQuery } from "@/lib/messages";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function EventsAdminPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const query = await searchParams;
  const events = listEvents();
  return (
    <>
      <h1>Events</h1>
      <SaveBanner saved={firstQuery(query.saved)} error={firstQuery(query.error)} />
      <p>
        Seeded nights are samples, not a real calendar. Uncheck “Sample placeholder” when an event
        is real. The public page labels anything still marked sample.
      </p>
      <h2>Add event</h2>
      <form className="form-grid" action="/api/admin/save" method="post">
        <input type="hidden" name="intent" value="event-add" />
        <div className="field">
          <label htmlFor="new-title">Title</label>
          <input id="new-title" name="title" required />
        </div>
        <div className="field">
          <label htmlFor="new-start">Date and start</label>
          <input id="new-start" name="starts_at" type="datetime-local" required />
        </div>
        <div className="field">
          <label htmlFor="new-blurb">Description</label>
          <textarea id="new-blurb" name="blurb" required />
        </div>
        <div className="field">
          <label htmlFor="new-price">Price, if there is one</label>
          <input id="new-price" name="price" />
        </div>
        <div className="field">
          <label htmlFor="new-photo">Photo URL, optional</label>
          <input id="new-photo" name="photo" placeholder="/events/poster.jpg" />
        </div>
        <div className="field">
          <label htmlFor="new-next">Next step, optional</label>
          <input id="new-next" name="next_step" />
        </div>
        <label className="check" htmlFor="new-sample">
          <input id="new-sample" type="checkbox" name="is_sample" />
          Sample placeholder
        </label>
        <button className="btn btn-solid" type="submit">
          Add event
        </button>
      </form>
      {events.map((event) => (
        <article key={event.id} className="item-card">
          <form className="form-grid" action="/api/admin/save" method="post">
            <input type="hidden" name="intent" value="event-update" />
            <input type="hidden" name="id" value={event.id} />
            {event.is_sample ? <span className="badge badge-warn">Sample</span> : null}
            <p>{formatEventStart(event.starts_at)}</p>
            <div className="field">
              <label htmlFor={`title-${event.id}`}>Title</label>
              <input id={`title-${event.id}`} name="title" defaultValue={event.title} required />
            </div>
            <div className="field">
              <label htmlFor={`start-${event.id}`}>Date and start</label>
              <input
                id={`start-${event.id}`}
                name="starts_at"
                type="datetime-local"
                defaultValue={event.starts_at}
                required
              />
            </div>
            <div className="field">
              <label htmlFor={`blurb-${event.id}`}>Description</label>
              <textarea id={`blurb-${event.id}`} name="blurb" defaultValue={event.blurb} required />
            </div>
            <div className="field">
              <label htmlFor={`price-${event.id}`}>Price, if there is one</label>
              <input id={`price-${event.id}`} name="price" defaultValue={event.price} />
            </div>
            <div className="field">
              <label htmlFor={`photo-${event.id}`}>Photo URL, optional</label>
              <input id={`photo-${event.id}`} name="photo" defaultValue={event.photo} />
            </div>
            <div className="field">
              <label htmlFor={`next-${event.id}`}>Next step, optional</label>
              <input id={`next-${event.id}`} name="next_step" defaultValue={event.next_step} />
            </div>
            <label className="check" htmlFor={`sample-${event.id}`}>
              <input
                id={`sample-${event.id}`}
                type="checkbox"
                name="is_sample"
                defaultChecked={event.is_sample}
              />
              Sample placeholder
            </label>
            <button className="btn" type="submit">
              Save event
            </button>
          </form>
          <form className="row-actions" action="/api/admin/save" method="post">
            <input type="hidden" name="intent" value="event-delete" />
            <input type="hidden" name="id" value={event.id} />
            <label className="check">
              <input type="checkbox" name="yes" value="1" required />
              Delete this event
            </label>
            <button className="btn btn-small btn-danger" type="submit">
              Delete event
            </button>
          </form>
        </article>
      ))}
    </>
  );
}
