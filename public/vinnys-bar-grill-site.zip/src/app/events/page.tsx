import { ConfirmedEvents } from "@/components/ConfirmedEvents";
import { TrackView } from "@/components/TrackView";
import { detroitToday, eventDate } from "@/lib/format";
import { listEvents } from "@/lib/db";
import { pageMeta } from "@/lib/seo";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const metadata = pageMeta(
  "/events",
  "Events",
  "Confirmed events at Vinny's Bar & Grill in Ypsilanti. The list stays empty until a real event is posted.",
);

export default function EventsPage() {
  const events = listEvents().filter((event) => !event.is_sample);
  const today = detroitToday();
  const upcoming = events.filter((event) => eventDate(event.starts_at) >= today);
  const earlier = events.filter((event) => eventDate(event.starts_at) < today);
  return (
    <div className="page wrap">
      <TrackView name="event_view" />
      <h1>Events</h1>
      <p className="lede">Only confirmed events are listed. Sample nights stay in the admin.</p>
      {events.length === 0 ? <ConfirmedEvents events={[]} /> : null}
      {upcoming.length ? (
        <section aria-labelledby="upcoming-heading">
          <h2 id="upcoming-heading">Upcoming</h2>
          <ConfirmedEvents events={upcoming} />
        </section>
      ) : null}
      {earlier.length ? (
        <section aria-labelledby="earlier-heading">
          <h2 id="earlier-heading">Earlier</h2>
          <ConfirmedEvents events={earlier} />
        </section>
      ) : null}
    </div>
  );
}
