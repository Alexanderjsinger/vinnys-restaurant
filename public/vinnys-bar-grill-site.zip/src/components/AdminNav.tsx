"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/admin", label: "Overview" },
  { href: "/admin/place", label: "Place" },
  { href: "/admin/story", label: "Story" },
  { href: "/admin/promo", label: "Promo" },
  { href: "/admin/menu", label: "Menu" },
  { href: "/admin/events", label: "Events" },
  { href: "/admin/ordering", label: "Ordering" },
  { href: "/admin/reservations", label: "Reservations" },
  { href: "/admin/inquiries", label: "Inquiries" },
];

export function AdminNav() {
  const path = usePathname();
  return (
    <div className="admin-bar">
      <nav aria-label="Admin" className="admin-nav">
        <ul>
          {LINKS.map((link) => {
            const current = link.href === "/admin" ? path === "/admin" : path === link.href;
            return (
              <li key={link.href}>
                <Link href={link.href} aria-current={current ? "page" : undefined}>
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <form action="/api/admin/logout" method="post">
        <button className="btn btn-small" type="submit">
          Log out
        </button>
      </form>
    </div>
  );
}
