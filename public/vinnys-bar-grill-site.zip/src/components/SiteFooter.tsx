import Link from "next/link";
import { HoursList } from "@/components/HoursList";
import { ORDER_URL, PHONE_DISPLAY, RESERVE_TEL, STREET_ADDRESS } from "@/lib/public";
import type { PublicSite } from "@/lib/types";

export function SiteFooter({ site }: { site: PublicSite }) {
  const phoneHref = site.phoneHref || RESERVE_TEL;
  const phoneLabel = site.phone || PHONE_DISPLAY;
  const orderUrl = site.toastUrl || ORDER_URL;
  return (
    <footer className="site-footer">
      <div className="wrap footer-grid">
        <div>
          <p className="footer-name">{site.name}</p>
          {site.tagline ? <p className="footer-tag">{site.tagline}</p> : null}
          <address>{site.address || STREET_ADDRESS}</address>
          <p>
            <a href={phoneHref} data-track="phone_click">
              {phoneLabel}
            </a>
          </p>
          {site.email ? (
            <p>
              <a href={`mailto:${site.email}`}>{site.email}</a>
            </p>
          ) : null}
        </div>
        <div>
          <h2>Hours</h2>
          <p className="lunch-line">Lunch daily, 11–3pm</p>
          <HoursList hours={site.hours} />
        </div>
        <nav aria-label="Footer">
          <ul>
            <li>
              <Link href="/menu">Menu</Link>
            </li>
            <li>
              <Link href="/events">Events</Link>
            </li>
            <li>
              <a href={orderUrl} target="_blank" rel="noopener noreferrer">
                Order
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            </li>
            <li>
              <Link href="/parties">Private parties</Link>
            </li>
            <li>
              <Link href="/contact">Contact</Link>
            </li>
            <li>
              <a href={phoneHref} data-track="phone_click">
                Call to reserve
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </footer>
  );
}
