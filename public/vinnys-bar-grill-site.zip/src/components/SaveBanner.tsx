import { adminError } from "@/lib/messages";

export function SaveBanner({ saved, error }: { saved?: string; error?: string }) {
  const message = adminError(error);
  if (message) {
    return (
      <p className="banner banner-bad" role="alert">
        {message}
      </p>
    );
  }
  if (saved) {
    return (
      <p className="banner banner-good" role="status">
        Saved.
      </p>
    );
  }
  return null;
}
