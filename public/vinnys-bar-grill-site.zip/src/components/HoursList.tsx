import { formatTime } from "@/lib/format";
import type { Hour } from "@/lib/types";

export function HoursList({ hours }: { hours: Hour[] }) {
  if (!hours.length) return <p>Hours have not been posted yet.</p>;
  const confirmed = hours.filter((hour) => hour.confirmed);
  const pending = hours.filter((hour) => !hour.confirmed);
  return (
    <>
      {confirmed.length ? <HourRows hours={confirmed} /> : null}
      {pending.length ? (
        <>
          <p className="unconfirmed-note">Not confirmed yet. Lunch daily, 11–3pm, is the printed menu.</p>
          <HourRows hours={pending} />
        </>
      ) : null}
    </>
  );
}

function HourRows({ hours }: { hours: Hour[] }) {
  return (
    <dl className="hours">
      {hours.map((hour) => (
        <div key={hour.id}>
          <dt>{hour.label}</dt>
          <dd>
            {formatTime(hour.opens)} – {formatTime(hour.closes)}
          </dd>
        </div>
      ))}
    </dl>
  );
}
