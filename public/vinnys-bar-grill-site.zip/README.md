# Vinny's Bar & Grill

A multi-page restaurant site for Vinny's Bar & Grill in Ypsilanti. It is meant to replace the GoDaddy one-pager at vinnysbargrill.com once someone points the domain at a host running this app.

**This project does not change DNS for vinnysbargrill.com.**

## Run

Requirements: Node.js 22 or newer, and build tools for `better-sqlite3` (`python3`, `make`, `g++`, and SQLite headers).

```bash
cd /cursor/stores/bc-9372d14d-41c8-4fa9-84cf-39adea69c698/site
cp .env.example .env.local
```

The project store is a slow FUSE disk. It does not support symlinks or rename, and deleting `node_modules` there can sit for many minutes. Keep dependencies and the Next build folder on local disk with a bind mount, then install:

```bash
bash scripts/mount-build-dirs.sh
npm install --prefer-offline
npm run dev
```

`.npmrc` omits optional dependencies and skips the audit call. That drops Sharp’s extra platform binaries. Next still needs its compiler, so `@next/swc-linux-x64-gnu` is a normal dependency. `better-sqlite3` ships a Linux prebuild in the package. The bind mounts last until this machine reboots. Run the script again on the next session before `npm install`. Do not `rm -rf node_modules` on the store.

Open http://localhost:3000

`.env.example` contains `ADMIN_PASSWORD=local-dev-only-change-me` for local development only. A copy is already in `.env.local` for this checkout. Change that password before the site is reachable by anyone else. Do not deploy the example password.

Production-style local run:

```bash
npm run build
npm start
```

Set `ADMIN_PASSWORD` in the server environment. Set `COOKIE_SECURE=true` only when the site is served over HTTPS. Leave it false for `http://localhost`, or the sign-in cookie will not stick.

The admin session lasts 12 hours.

## Edit content

Sign in at `/admin`.

| Screen | What it changes |
| --- | --- |
| Place | Name, address, phone, email, hours |
| Story | Tagline, owner, opening date, former venue, cuisine notes |
| Promo | Home headline, body, optional link |
| Menu | Sections and items (name, description, price, section) |
| Events | Title, start, short blurb |
| Ordering | Toast online ordering URL |
| Reservations | Provider and booking URL |
| Inquiries | Private-party notes saved from the public form |

Page layout is not editable in the admin.

Saves go into `data/site.sqlite`. Deleting that file and restarting reseeds the printed lunch menu, sample events, and unconfirmed starting facts. Party inquiries live in the same file, so treat it as private.

The party form stores name, email, date, party size, and message in SQLite. It does not send email.

## Toast ordering URL

Admin → Ordering. Paste the Toast online ordering URL and save.

Public Order buttons go to `https://order.toasttab.com/online/vinny-s-bar-grill-705-west-cross-street`. `/order` redirects there. The same URL is saved in Ordering when that field is still empty.

## Reservation provider

Admin → Reservations. The provider is `none`, `toast` (Toast Tables), `opentable`, or `resy`, plus a booking URL.

The public button says **Call to reserve** and dials `tel:7349057051`. There is no reservation form. Phone `734-905-7051` is confirmed.

## Sample vs unconfirmed

**Lunch menu** items are the printed lunch menu (daily 11–3pm), including the spellings on that card. They are not samples. There is no dinner menu on the site. Placeholder events stay in the admin and are omitted from the public events page.

**Unconfirmed** facts are starting values from public listings and the current one-page site. The admin shows an Unconfirmed badge until you check “confirmed.”

Phone `734-905-7051` is confirmed. Shown to guests even while unconfirmed: restaurant name, tagline, address, and hours.

Hidden until confirmed: owner, opening date, former venue, and cuisine notes.

`content/specials.json` is kept and is not shown on the homepage. The homepage food row shows Vinny's Burger and Spicy Cauliflower from the printed lunch menu, with their photos. Pasta and cheesecake are not shown as menu dishes. Event posters are image files in `public/events`. When that folder has none, the hero is `public/hero/meet-me.jpg` with the line “Meet me at Vinny's.” The homepage venue band stays empty until an owner photo is added. The storefront photo is not the hero.

## DNS

Running, building, or editing this site does not change DNS for vinnysbargrill.com.
